package recyclerview_ads.example.com.ad_recyclerview.RecyclerViewNativeAds;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.NativeExpressAdView;

import java.util.ArrayList;

import recyclerview_ads.example.com.ad_recyclerview.Linear_RecyclerView_ads.User;
import recyclerview_ads.example.com.ad_recyclerview.R;

public class NativeGridUserAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    ArrayList<User> arrUser;
    RecyclerView rvUsers;

    public NativeGridUserAdapter (ArrayList<User> arrUser, RecyclerView rvUsers) {
        this.arrUser = arrUser;
        this.rvUsers = rvUsers;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;
        if (i == 0) {

                    view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.native_viewholder, null);
            return new AdsViewHolder(view);
        } else {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.grid_user_viewholder, null);

            return new UserViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder.getItemViewType() == 1) {
            UserViewHolder mUserViewHolder = (UserViewHolder) viewHolder;
            mUserViewHolder.tvUserName.setText("Name : " + arrUser.get(i).getUserName());
            mUserViewHolder.tvUserAge.setText("Age : " + String.valueOf(arrUser.get(i).getUserAge()));
        } else if (viewHolder.getItemViewType() == 0) {
            AdsViewHolder mAdsViewHolder = (AdsViewHolder) viewHolder;
        }

    }

    @Override
    public int getItemCount() {
        return arrUser.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (arrUser.get(position) == null) {
            return 0;
        } else {
            return 1;
        }
    }

    class AdsViewHolder extends RecyclerView.ViewHolder {

        public AdsViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    class UserViewHolder extends RecyclerView.ViewHolder {
        TextView tvUserName, tvUserAge;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvUserAge = itemView.findViewById(R.id.tvUserAge);
        }
    }
}
