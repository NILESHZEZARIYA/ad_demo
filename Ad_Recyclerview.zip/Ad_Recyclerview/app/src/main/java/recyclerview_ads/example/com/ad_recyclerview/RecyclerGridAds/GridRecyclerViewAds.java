package recyclerview_ads.example.com.ad_recyclerview.RecyclerGridAds;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

import recyclerview_ads.example.com.ad_recyclerview.Linear_RecyclerView_ads.User;
import recyclerview_ads.example.com.ad_recyclerview.R;

public class GridRecyclerViewAds extends AppCompatActivity {

    RecyclerView rvUsers;
    ArrayList<User> arrUser;
    ArrayList<User> arrUserWithAd;
    GridUserAdapter mGridUserAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bind();
        init();
    }

    private void bind() {
        rvUsers = findViewById(R.id.rvUsers);
    }

    private void init() {


        arrUserWithAd = new ArrayList<>();
        arrUser = new ArrayList<>();
        loadData();

       mGridUserAdapter=  new GridUserAdapter(arrUserWithAd,rvUsers);
        rvUsers.setHasFixedSize(true);
        GridLayoutManager mGridLayoutManager= new GridLayoutManager(this,2);
        mGridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int i) {
                if(arrUserWithAd.get(i)==null){
                        return 2;
                }else{
                    return 1;
                }
            }
        });
        rvUsers.setLayoutManager(mGridLayoutManager);
        rvUsers.setAdapter(mGridUserAdapter);
    }


    private void loadData() {
        arrUser.clear();
        arrUser.add(new User("AA", 25));
        arrUser.add(new User("BB", 25));
        arrUser.add(new User("CC", 25));
        arrUser.add(new User("DD", 25));
        arrUser.add(new User("EE", 25));
        arrUser.add(new User("FF", 25));
        arrUser.add(new User("GG", 25));
        arrUser.add(new User("HH", 25));
        arrUser.add(new User("II", 25));
        arrUser.add(new User("JJ", 25));
        arrUser.add(new User("KK", 25));
        arrUser.add(new User("LL", 25));
        arrUser.add(new User("MM", 25));
        arrUser.add(new User("NN", 25));
        arrUser.add(new User("OO", 25));
        arrUser.add(new User("PP", 25));
        arrUser.add(new User("QQ", 25));
        arrUser.add(new User("RR", 25));
        arrUser.add(new User("SS", 25));
        arrUser.add(new User("TT", 25));
        arrUser.add(new User("UU", 25));
        arrUser.add(new User("VV", 25));
        arrUser.add(new User("WW", 25));
        arrUser.add(new User("XX", 25));
        arrUser.add(new User("YY", 25));
        arrUser.add(new User("ZZ", 25));


        //

        for (int i = 0; i < arrUser.size(); i++) {
            if (i % 4 == 0 && i!=0)  {

                arrUserWithAd.add(null);
            }
            arrUserWithAd.add(arrUser.get(i));

        }
    }
}
