package recyclerview_ads.example.com.ad_recyclerview;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import recyclerview_ads.example.com.ad_recyclerview.Linear_RecyclerView_ads.LinearRecyclerViewAds;
import recyclerview_ads.example.com.ad_recyclerview.RecyclerGridAds.GridRecyclerViewAds;
import recyclerview_ads.example.com.ad_recyclerview.RecyclerViewNativeAds.NativeGridRecyclerViewAds;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        findViewById(R.id.btnLinear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainActivity.this, LinearRecyclerViewAds.class));

            }
        });

        findViewById(R.id.btnGrid).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainActivity.this, GridRecyclerViewAds.class));

            }
        });
        findViewById(R.id.btnGridNative).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainActivity.this, NativeGridRecyclerViewAds.class));

            }
        });
    }
}
