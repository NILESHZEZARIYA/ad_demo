package recyclerview_ads.example.com.ad_recyclerview.Linear_RecyclerView_ads;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;

import recyclerview_ads.example.com.ad_recyclerview.Linear_RecyclerView_ads.User;
import recyclerview_ads.example.com.ad_recyclerview.R;

public class UserAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    ArrayList<User> arrUser;

    public UserAdapter(ArrayList<User> arrUser) {
        this.arrUser = arrUser;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;
        if (i == 0) {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.ads_viewholder, null);
            return new AdsViewHolder(view);
        } else {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.user_viewholder, null);
            return new UserViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder.getItemViewType() == 1) {
            UserViewHolder mUserViewHolder = (UserViewHolder) viewHolder;
            mUserViewHolder.tvUserName.setText("Name : " + arrUser.get(i).getUserName());
            mUserViewHolder.tvUserAge.setText("Age : " + String.valueOf(arrUser.get(i).getUserAge()));
        } else if (viewHolder.getItemViewType() == 0) {
            AdsViewHolder mAdsViewHolder = (AdsViewHolder) viewHolder;
            AdRequest mAdRequest = new AdRequest.Builder().build();

            mAdsViewHolder.mAdView.loadAd(mAdRequest);
        }

    }

    @Override
    public int getItemCount() {
        return arrUser.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (arrUser.get(position)==null) {
            return 0;
        } else {
            return 1;
        }
    }

    class AdsViewHolder extends RecyclerView.ViewHolder {
        AdView mAdView;

        public AdsViewHolder(@NonNull View itemView) {
            super(itemView);
            mAdView = itemView.findViewById(R.id.adView1);
        }
    }

    class UserViewHolder extends RecyclerView.ViewHolder {
        TextView tvUserName, tvUserAge;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvUserAge = itemView.findViewById(R.id.tvUserAge);
        }
    }
}
